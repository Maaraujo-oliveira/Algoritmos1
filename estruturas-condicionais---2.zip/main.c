#include <stdio.h>

int main() {
    // Declaração de variável
    int n;  // Armazena o número inteiro informado pelo usuário

    // Entrada de dados
    printf("Digite um número inteiro: ");
    scanf("%d", &n);

    // Processamento: verifica se o número é positivo ou negativo
    
    // Saida de dados
    if (n == 0) {
        printf("Zero\n");
    } if (n > 0) {
        printf("Positivo\n");   // número negativo
    } if (n < 0) {
        printf("Negativo\n");
    }

    return 0;
}
