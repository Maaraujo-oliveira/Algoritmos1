#include <stdio.h>

int main() {
    // Declaração de variável
    int numero;  // Armazena o número inteiro informado pelo usuário

    // Entrada de dados
    printf("Digite um número inteiro: ");
    scanf("%d", &numero);

    // Processamento: verifica se o número é positivo ou negativo
    // Considera o número zero como positivo
    if (numero >= 0) {
        // Saída de dados
        printf("Positivo\n");
    } else {
        printf("Negativo\n");   // número negativo
    }

    return 0;
}
